<div class="ai1ec_repeat_centered_content">
  <label for="ai1ec_yearly_count">
	  <?php _e( 'Every', AI1EC_PLUGIN_NAME ) ?>:
  </label>
  <?php echo $count ?>
  <label for="ai1ec_yearly_date_select">
	  <?php _ex( 'In', 'Recurrence editor - yearly tab', AI1EC_PLUGIN_NAME ) ?>:
  </label>
  <div style="clear: both;"></div>
  <?php echo $year ?>
</div>