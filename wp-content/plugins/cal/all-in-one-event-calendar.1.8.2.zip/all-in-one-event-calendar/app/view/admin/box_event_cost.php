<h4 class="ai1ec-section-title"><?php _e( 'Event cost', AI1EC_PLUGIN_NAME ); ?></h4>
<table class="ai1ec-form">
	<tbody>
		<tr>
			<td class="ai1ec-first">
				<label for="ai1ec_cost">
					<?php _e( 'Cost', AI1EC_PLUGIN_NAME ); ?>:
				</label>
			</td>
			<td>
				<input type="text" name="ai1ec_cost" id="ai1ec_cost" value="<?php echo $cost; ?>" />
			</td>
		</tr>
	</tbody>
</table>
